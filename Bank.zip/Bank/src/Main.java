import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("1. Yeni Hesap Oluştur");
            System.out.println("2. Para Yatır");
            System.out.println("3. Para Çek");
            System.out.println("4. Sistem Tarihini Ayarla");
            System.out.println("5. Hesapları Göster");
            System.out.println("6. Çekiliş");
            System.out.println("7. Çıkış");
            System.out.print("Seçiminizi yapın: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // newline karakterini tüket

            switch (choice) {
                case 1:
                    createAccount(bank, scanner);
                    break;
                case 2:
                    deposit(bank, scanner);
                    break;
                case 3:
                    withdraw(bank, scanner);
                    break;
                case 4:
                    bank.set_dd_mm_yy();
                    break;
                case 5:
                    showAccounts(bank);
                    break;
                case 6:
                    bank.sortition();
                    break;
                case 7:
                    exit = true;
                    break;
                default:
                    System.out.println("Geçersiz seçim.");
                    break;
            }
            System.out.println();
        }
        System.out.println("Programdan çıkılıyor...");
    }

    private static void createAccount(Bank bank, Scanner scanner) {
        System.out.println("Hesap Türünü Seçin:");
        System.out.println("1. Kısa Vadeli Hesap");
        System.out.println("2. Uzun Vadeli Hesap");
        System.out.println("3. Özel Hesap");
        System.out.println("4. Vadesiz Hesap");
        System.out.print("Seçiminizi yapın: ");
        int accountType = scanner.nextInt();
        scanner.nextLine(); // newline karakterini tüket

        System.out.print("Hesap Numarasını Girin: ");
        int accountID = scanner.nextInt();
        scanner.nextLine(); // newline karakterini tüket

        System.out.print("Bakiyeyi Girin: ");
        int balance = scanner.nextInt();
        scanner.nextLine(); // newline karakterini tüket

        switch (accountType) {
            case 1:
                bank.createShortTermAccount(accountID, balance);
                break;
            case 2:
                bank.createLongTermAccount(accountID, balance);
                break;
            case 3:
                bank.createSpecialAccount(accountID, balance);
                break;
            case 4:
                bank.createCurrentAccount(accountID, balance);
                break;
            default:
                System.out.println("Geçersiz hesap türü.");
                break;
        }
        System.out.println("Hesap oluşturuldu.");
    }

    private static void deposit(Bank bank, Scanner scanner) {
        System.out.print("Hesap Numarasını Girin: ");
        int accountID = scanner.nextInt();
        scanner.nextLine(); // newline karakterini tüket

        System.out.print("Yatırılacak Miktarı Girin: ");
        int amount = scanner.nextInt();
        scanner.nextLine(); // newline karakterini tüket

        bank.deposit(accountID, amount);
        System.out.println("Para yatırıldı.");
    }

    private static void withdraw(Bank bank, Scanner scanner) {
    System.out.print("Hesap Numarasını Girin: ");
    int accountID = scanner.nextInt();
    scanner.nextLine(); // newline karakterini tüket

    System.out.print("Çekilecek Miktarı Girin: ");
    int amount = scanner.nextInt();
    scanner.nextLine(); // newline karakterini tüket

    bank.withdraw(accountID, amount);
    System.out.println("Para çekildi.");
    }


    private static void showAccounts(Bank bank) {
    System.out.println("Hesaplar: ");
    List<Account> accounts = bank.getAccounts();
    for (Account account : accounts) {
        System.out.println(account.getID());
    }
}
}
