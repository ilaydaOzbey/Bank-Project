    public class ShortTermAccount extends Account {
    public static final double interestRate = 0.17;
    public static final int minBalance = 1000;

    public ShortTermAccount(int accountID, int balance) {
        super(accountID, balance);
    }

    @Override
    public double calculateBenefit() {
        return (int)balance * interestRate / 365;
    }
    
}
