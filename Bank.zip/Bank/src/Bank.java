import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


public class Bank {
    public List<Account> accounts;
    public String date = "05.05.2023";

    public Bank() {
        accounts = new ArrayList<>();
    }
    
    public void set_dd_mm_yy() {
		System.out.println("Yeni tarihi giriniz.");
		Scanner input = new Scanner(System.in);
		this.date = input.nextLine();
		System.out.println("Tarih değiştirildi.");
	}
    
    
    public void sortition() {
        List<SpecialAccount> specialAccounts = new ArrayList<>();
        for (Account account : accounts) {
            if (account instanceof SpecialAccount) {
                specialAccounts.add((SpecialAccount) account);
            }
        }
        if (specialAccounts.isEmpty()) {
            System.out.println("Özel hesap bulunamadı.");
            return;
        }
        int totalPoints = 0;
        for (SpecialAccount account : specialAccounts) {
            totalPoints += account.getBalance()/2000;
        }
        Random random = new Random();
        int winningNumber = random.nextInt(totalPoints) + 1;
        int accumulatedPoints = 0;
        for (SpecialAccount account : specialAccounts) {
            accumulatedPoints += account.getBalance()/2000;
            if (accumulatedPoints >= winningNumber) {
                System.out.println("Tebrikler " + account.getID() + " numaralı ID çekilişi kazandı!");
                deposit(account.getID(),10000);
                break;
            }
        }
    }

    public void createShortTermAccount(int accountID, int balance) {
        if (balance >= ShortTermAccount.minBalance) {
            Account account = new ShortTermAccount(accountID, balance);
            accounts.add(account);
            System.out.println("Kısa vadeli hesap oluşturuldu. Hesap No: " + accountID +" " + date);
        } else {
            System.out.println("Hesap açmak için minimum bakiye gereksinimini karşılamıyor.");
        }
    }

    public void createLongTermAccount(int accountID, int balance) {
        if (balance >= LongTermAccount.minBalance) {
            Account account = new LongTermAccount(accountID, balance);
            accounts.add(account);
            System.out.println("Uzun vadeli hesap oluşturuldu. Hesap No: " + accountID + " " + date);
        } else {
            System.out.println("Hesap açmak için minimum bakiye gereksinimini karşılamıyor.");
        }
    }

    public void createSpecialAccount(int accountID, int balance) {
        Account account = new SpecialAccount(accountID, balance);
        accounts.add(account);
        System.out.println("Özel hesap oluşturuldu. Hesap No: " + accountID + " " + date);
    }

    public void createCurrentAccount(int accountID, int balance) {
        Account account = new CurrentAccount(accountID, balance);
        accounts.add(account);
        System.out.println("Cari hesap oluşturuldu. Hesap No: " + accountID + " " + date);
    }

    public void deposit(int accountID, int amount) {
        Account account = findAccount(accountID);
        if (account != null) {
            account.deposit(amount);
        } else {
            System.out.println("Hesap bulunamadı.");
        }
    }

    public void withdraw(int accountID, int amount) {
        Account account = findAccount(accountID);
        if (account != null) {
            account.withdraw(amount);
        } else {
            System.out.println("Hesap bulunamadı.");
        }
    }

    public void showAccounts() {
        for (Account account : accounts) {
            System.out.println("Hesap No: " + account.getID());
            System.out.println("Son 5 işlem:");
            // Son 5 işlemi göster
        }
    }

    private Account findAccount(int accountID) {
        for (Account account : accounts) {
            if (account.getID() == accountID) {
                return account;
            }
        }
        return null;
    }   
    
    public List<Account> getAccounts() {
        return accounts;
    }
    
}
