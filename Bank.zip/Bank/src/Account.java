    public abstract class Account {
    public int accountID;
    public int balance;
    private String date;

    public Account(int accountID, int balance) {
        this.accountID = accountID;
        this.balance = balance;
        this.date=date;
    }

    public void deposit(int amount) {
        balance += amount;
        System.out.println("Yatırılan miktar: " + amount + " TL");
        System.out.println("Güncel bakiye: " + balance + " TL");
    }

    public void withdraw(int amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Çekilen miktar: " + amount + " TL");
            System.out.println("Güncel bakiye: " + balance + " TL");
        } else {
            System.out.println("Yetersiz bakiye! İşlem gerçekleştirilemedi.");
        }
    }

    public int getBalance() {
        return balance;
    }

    public int getID() {
        return accountID;
    }
    
    public String  getDate() 
	{
            return date;
        }
	

    public abstract double calculateBenefit();
}
