    public class SpecialAccount extends Account{
    public static final double interestRate = 0.12;

    public SpecialAccount(int accountID, int balance) {
        super(accountID, balance);
    }

    @Override
    public double calculateBenefit() {
        return (int)balance * interestRate / 365;
    }
}
