    public class CurrentAccount extends Account {
    
    public CurrentAccount(int accountID, int balance) {
        super(accountID, balance);
    }

    @Override
    public double calculateBenefit() {
        return 0;
    }
}
